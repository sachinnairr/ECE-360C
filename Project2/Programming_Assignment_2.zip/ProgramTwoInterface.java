public  interface ProgramTwoInterface {
    public int findMinimumRouteDistance(Problem problem);
    public int findMinimumLength(Problem problem);
    public String toString(Problem problem);
}